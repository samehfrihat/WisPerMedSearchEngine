const objectToQueryString = (object) => {
  return Object.entries(object)
    .map((q) => q[0] + "=" + String(q[1]))
    .join("&");
};

export default objectToQueryString;


