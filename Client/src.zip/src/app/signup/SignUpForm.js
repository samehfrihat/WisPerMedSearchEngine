import React from "react";
import { useEffect, useState } from "react";
import { useHistory } from "react-router";
import Spinner from "../../components/Spinner";
import { url } from "../../config";
import "../login/login.css";
import { Box } from "@mui/system";
import Stack from "@mui/material/Stack";
import { Typography, Button, CircularProgress, TextField } from "@mui/material";

import Logo from "../../components/Logo";
import StyledLink from "../../components/StyledLink";

const SignUpForm = () => {
  const [loading, setLoading] = useState(false);
  const history = useHistory();
  const [response, setResponse] = useState({});
  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
  });
  const email_pattern = "^[a-zA-Z0-9]+@[a-zA-Z0-9]+\\.[A-Za-z]+$";
  let token = JSON.parse(localStorage.getItem("token"));

  // access check
  useEffect(() => {
    if (token) {
      if (token.status === 200) {
        history.push({ pathname: "/" });
      }
    }
  });

  useEffect(() => {
    if (response["status"] === 200) {
      history.push("/login");
    }
    setLoading(false);
  }, [response, history]);

  const onSubmit = (e) => {
    e.preventDefault();

    if (!(data.name && data.email && data.password)) {
      alert("Please fill up all information !");
      return;
    }

    if (!RegExp(email_pattern).test(data.email)) {
      alert("Please add a correct email !");
      return;
    }

    fetch(`${url}/signup/`, {
      method: "POST",
      headers: {
        "Content-type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((res) => res.json())
      .then((res) => {
        setResponse(res);
        console.log(res);
      });

    setLoading(true);
  };

  const handle = (e) => {
    const newData = { ...data };
    newData[e.target.name] = e.target.value;
    setData(newData);
  };

  return (
    <div className="bg">
      <Box className="containers" id="container">

        <form onSubmit={onSubmit}>
          <Box display="flex" flexDirection="column" alignItems="center" mb={2}>
            <Logo />
            <Typography variant="h6">Create new Account</Typography>

            <StyledLink to="/login">already have account?</StyledLink>
          </Box>
          <Box>
            <Stack alignItems="stretch" mb={2}>
              <TextField
                type="email"
                label="Email"
                value={data.email}
                onChange={handle}
                name="email"
                size={"small"}
                margin="dense"
              />
              <TextField
                type="password"
                label="Password"
                value={data.password}
                onChange={handle}
                name="password"
                size={"small"}
                margin="dense"
              />
              <TextField
                type="userName"
                label="Username"
                value={data.userName}
                onChange={handle}
                name="userName"
                size={"small"}
                margin="dense"
              />
              <TextField
                type="Gender"
                label="Gender"
                value={data.Gender}
                onChange={handle}
                name="Gender"
                size={"small"}
                margin="dense"
              />

              <TextField
                type="specialist In"
                label="specialist In"
                value={data.specialistIn}
                onChange={handle}
                name="specialistIn"
                size={"small"}
                margin="dense"
              />

              <TextField
                type="language"
                label="language"
                value={data.language}
                onChange={handle}
                name="language"
                size={"small"}
                margin="dense"
              />
            </Stack>
            <Stack spacing={1}>
              <Button
                startIcon={loading ? <CircularProgress size={14} /> : undefined}
                disabled={loading}
                type="submit"
                color="pallete1"
                variant="contained"
                sx={{ borderRadius: 50 }}
                disableElevation
              >
                Create Account
              </Button>
            </Stack>
          </Box>
          {response["status"] === 400 && <p>{response["error"]}</p>}
        </form>

        {/* <div className="overlay-container">
                    <div className="overlay">
                        <div className="overlay-panel overlay-right">
                            <h1 className="h1">Welcome Back!</h1>
                            <p className="p">To keep connected with us please login with your personal info</p>
                            <Link to="/login"><button className="Button ghost" id="signIn">Sign In</button></Link>
                        </div>
                    </div>
                </div> */}
      </Box>
    </div>
  );
};

export default SignUpForm;
