import * as React from "react";
import { useState, useEffect } from "react";
import { url } from "../../config";
import { useHistory } from "react-router";
import { useLocation } from "react-router-dom";
import useAuth from "../../hooks/useAuth";
import objectToQueryString from "../../utils/objectToQueryString";
import { QueryBuilderTwoTone } from "@mui/icons-material";
const QUERY_PARAMS_WHITE_LIST = [
  "query",
  "category",
  "medicalAbstracts",
  "clinicalTrials"
];

const SearchResult = () => {
  const { search: searchLocation } = useLocation();
  const search = React.useMemo(() => {
    const params = new URLSearchParams(searchLocation);
    const search = {};
    for (let key of QUERY_PARAMS_WHITE_LIST) {
      if (params.get(key)) {
        search[key] = params.get(key);
      }
    }

    return search;
  }, [searchLocation]);

  console.log('search : ' ,search )

  const { token } = useAuth();

  const history = useHistory();
  const [loading, setLoading] = useState(true);
  const [newPages, setPages] = useState();
  
  const fetchpages = (search) => {
    setLoading(true);
    fetch(`${url}/search_query/?${objectToQueryString(search)}`)
      .then((response) => response.json())
      .then((json) => {
        setPages(json);
        setLoading(false);
      })
      .catch((e) => {
        setLoading(true);
      });
  };

  useEffect(() => {
    if (search.query) {
      fetchpages(search);
    }
    //go to main page if you didn't enter a query
    else {
      history.push({ pathname: "/" });
    }
  }, [search]);

  useEffect(() => {
    if (search.query) {
      fetch(`${url}/search_data/`, {
        method: "POST",
        headers: {
          "Content-type": "application/json",
        },
        body: JSON.stringify({
          email: token.email,
          query: search.query,
          pages: newPages,
        }),
      });
    }
    console.log('test' , search.query)
  }, [newPages, search.query]);

  const getData = (props) => {
    const article_url = props.target.parentNode.parentNode.href;
    const title = props.target.innerHTML;
    console.log({ url: article_url, title: title });
    fetch(`${url}/get_article/`, {
      method: "POST",
      headers: {
        "Content-type": "application/json",
      },
      body: JSON.stringify({
        email: token.email,
        search_Query: search.query,
        url: article_url,
        title: title,
      }),
    });
  };

  return (
    <div className="result">
      {loading ? (
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%,-50%)",
          }}
        >
          Spinner placeholder
        </div>
      ) : (
        <>
          <hr />
          <div className="docs">
            {newPages &&
            newPages.map((doc, index) => (
              <div className="block">
                <a
                  key={index}
                  href={doc.url}
                  target="_blank"
                  rel="noreferrer"
                  onClick={getData}
                >
                  <div key={index} className="task">
                    <h3>{doc.brief_title}</h3>
                    <p>{doc.brief_summary}</p>
                  </div>
                </a>
                <div className="props">
                  <div className="prop">
                    <label>Technicality:</label>
                    <input
                      type="range"
                      id="cellWidth"
                      min="0"
                      max="100"
                      value={doc.Ease_of_reading}
                      disabled=""
                    ></input>
                    <output>{doc.Ease_of_reading}</output>
                  </div>
                  <div></div>
                  <div className="prop">
                    <label>Readability: </label>
                    <input
                      type="range"
                      id="cellWidth"
                      min="0"
                      max="100"
                      value={doc.Political_bias}
                      disabled=""
                    ></input>
                    <output>{doc.Political_bias}</output>
                  </div>
                  <div className="prop">
                    <label>Level of Evidence: </label>
                    <input
                      type="range"
                      id="cellWidth"
                      min="0"
                      max="100"
                      value={doc.Sentiment}
                      disabled=""
                    ></input>
                    <output>{doc.Sentiment}</output>
                  </div>
                  <div></div>
                  <div className="prop">
                    <label>Stage of Treatment: </label>
                    <input
                      type="range"
                      id="cellWidth"
                      min="0"
                      max="100"
                      value={doc.Objectivity}
                      disabled=""
                    ></input>
                    <output>{doc.Objectivity}</output>
                  </div>
                </div>
              </div>
            ))}
            {newPages.length === 0 && (
              <h3 className="notFound">
                Your search - {search.query} - did not match any document
              </h3>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default SearchResult;
