import SearchResult from "./SearchResult";

export default {
    screen: SearchResult,
}