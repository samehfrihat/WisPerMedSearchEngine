import LoginForm from "./LoginForm";

export default {
    screen: LoginForm,
}