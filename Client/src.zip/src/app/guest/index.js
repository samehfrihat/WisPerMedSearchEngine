import GuestForm from './GuestForm'

export default{
    screen:GuestForm
}