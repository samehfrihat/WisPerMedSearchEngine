import "../login/login.css";
import React from "react";
import { useEffect, useState } from "react";
import { Box } from "@mui/system";
import Stack from "@mui/material/Stack";
import Spinner from "../../components/Spinner";
import { useHistory } from "react-router";
import { saveSearchSettings } from "./api";
import Logo from "../../components/Logo";
import { styled } from "@mui/material/styles";
import { Typography, TextField, CircularProgress, Button } from "@mui/material";
import StyledLink from "../../components/StyledLink";

const GuestForm = () => {
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState({});
  const [data, setData] = useState({
    email: "",
    password: "",
  });

  let token = JSON.parse(localStorage.getItem("token"));
  const history = useHistory();

  // access check
  // useEffect(() => {
  //   if (token) {
  //     if (token.status === 200) {
  //       history.push({ pathname: "/" });
  //     }
  //   }
  // });

  useEffect(() => {
    if (response["status"] === 200) {
      /* window.location.reload(false) */
      //   history.push({ pathname: "/" });
    }
    setLoading(false);
  }, [response, history]);

  const onSubmit = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      const res = await saveSearchSettings(
        data.language,
        data.Gender,
        data.specialistIn
      );
      setResponse(res);
      localStorage.setItem("guest", JSON.stringify(1));
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  const handle = (e) => {
    const newData = { ...data };
    newData[e.target.id] = e.target.value;
    setData(newData);
  };

  return (
    <div className="bg">
    
        <form onSubmit={onSubmit}  className="containers" id="container">
   
          <Box display="flex" flexDirection="column" alignItems="center" mb={2}>
          <Logo />
            <Typography variant="h6">Login as guests</Typography>
            <StyledLink to="/login">already have account?</StyledLink>
          </Box>

          <Box>
            <Stack alignItems="stretch" mb={1}>
              <TextField
                type="language"
                label="Language"
                value={data.Language}
                onChange={(e) => handle(e)}
                name="language"
                size={"small"}
                margin="dense"
              />
              <TextField
                type="Gender"
                label="Gender"
                value={data.Gender}
                onChange={(e) => handle(e)}
                name="Gender"
                size={"small"}
                margin="dense"
              />
              <TextField
                type="specialistIn"
                label="specialistIn"
                value={data.specialistIn}
                onChange={(e) => handle(e)}
                name="specialistIn"
                size={"small"}
                margin="dense"
              />
            </Stack>

              <Button
                startIcon={loading ? <CircularProgress size={14} /> : undefined}
                disabled={loading}
                type="submit"
                color="pallete1"
                variant="contained"
                sx={{ borderRadius: 50 }}
                disableElevation
                fullWidth
              >
                Save And Continue
              </Button>

          </Box>
          {response["status"] === 400 && <p>{response["error"]}</p>}
        </form> 
    </div>
  );
};

export default GuestForm;
