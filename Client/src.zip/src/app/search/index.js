import Search from './Search'

export default{
    screen: Search,
}