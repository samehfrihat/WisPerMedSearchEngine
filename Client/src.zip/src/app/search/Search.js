import { useState } from "react";
import { useHistory } from "react-router";
import * as React from "react";
import { Link } from "react-router-dom";
import { url } from "../../config";
import "./search.css";
import Box from "@mui/material/Box";
import { Button, Stack } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import InsertDriveFileIcon from "@mui/icons-material/InsertDriveFile";
import InsertChartIcon from "@mui/icons-material/InsertChart";
import SearchForm from "../../components/SearchForm";
import Image from "../../components/Image";
import useAuth from "../../hooks/useAuth";
import useSearchForm from "../../hooks/useSearchForm";

const Search = () => {
  const search = useSearchForm();

  return (
    <div>
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div className="container" style={{ marginTop: "10vh" }}>
          <Box sx={{ paddingBottom: "8vh" }}>
            <Image src="../WisPerMed.png" />
          </Box>
          <SearchForm {...search} />
          <Box
            sx={{ paddingTop: 5, display: "flex", justifyContent: "center" }}
          >
            <Stack>
              <IconButton
                aria-label="search"
                type="submit"
                sx={{
                  backgroundColor: "#1CBDEF",
                  width: 120,
                  height: 120,
                  margin: 5,
                  color: "#1876D1",
                }}
                onClick={() => {
                  search.onSubmit({
                    medicalAbstracts: true,

                  });
                }}
              >
                <InsertDriveFileIcon sx={{ color: "#fff", fontSize: 50 }} />
              </IconButton>
              <Box>Medical Abstracts</Box>
            </Stack>

            <Stack>
              <IconButton
                aria-label="search"
                type="submit"
                sx={{
                  backgroundColor: "#08AA86",
                  width: 120,
                  height: 120,
                  margin: 5,
                }}
                onClick={() => {
                  search.onSubmit({
                    clinicalTrials: true,
                  });
                }}
              >
                <InsertChartIcon sx={{ color: "#fff", fontSize: 50 }} />
              </IconButton>
              <Box>Clinical Trials</Box>
            </Stack>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default Search;
