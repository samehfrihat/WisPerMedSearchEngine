import "./App.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import Login from "./app/login";
import Signup from "./app/signup";
import Search from "./app/search";
import SearchResult from "./app/searchResult";
import Layout from "./components/Layout";
import GuestForm from "./app/guest";
function App() {
  return (
    <Router>
      <Switch>
        <Route path="/" exact>
          <Layout search={false} logo={false}>
            <Search.screen  />
          </Layout>
        </Route>

        <Route path="/login" exact>
          <Login.screen />
        </Route>

        <Route path="/signup" exact>
          <Signup.screen />
        </Route>

        <Route path="/result" exact>
          <Layout>
            <SearchResult.screen />
          </Layout>
        </Route>

        <Route path="/guest" exact>
        
            <GuestForm.screen />
        
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
