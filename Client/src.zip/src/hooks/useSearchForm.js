import { useState, useEffect } from "react";
import { useHistory } from "react-router";
import { useLocation } from "react-router-dom";
import objectToQueryString from "../utils/objectToQueryString"

const DEFAULT_CATEGORY = "Medical genetics";

const useSearchForm = () => {
  const { search: searchLocation } = useLocation();

  const history = useHistory();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState(DEFAULT_CATEGORY);

  useEffect(() => {
    const params = new URLSearchParams(searchLocation);

    setQuery(params.get("query"));
    setCategory(params.get("category") || DEFAULT_CATEGORY);
  }, [searchLocation]);

  const onSubmit = (params = {}) => {
    if (!query) {
      return;
    }

    const queryString = objectToQueryString({
        ...params,
        query,
        category,
      })

      console.log(queryString, ' queryString')

    history.push({
      pathname: "/result",
      search: queryString,
    });
  };

  return {
    query,
    setQuery,
    category,
    setCategory,
    onSubmit,
  };
};

export default useSearchForm;
