import { useMemo } from "react";
import { useHistory } from "react-router";
import { url } from "../config";

export default function useAuth() {
  
  let token = useMemo(() => JSON.parse(localStorage.getItem("token")), []);

  const history = useHistory();

  const isAuthorized = token && token.status === 200;

  const logout = () => {
    fetch(`${url}/logout/`, {
      method: "POST",
      headers: {
        "Content-type": "application/json",
      },
      body: JSON.stringify(token),
    })
      .then((res) => res.json())
      .then((res) => {
        localStorage.removeItem("token");
        history.push("/login");
      });
  };

  return {
    token,
    isAuthorized,
    logout,
  };
}
