import React from "react";
import Image from "./Image";

export default function Logo({ width = 50, height = 50, ...rest }) {
  return (
    <Image {...rest} width={width} height={height} src="/WisPerMed_Main.png" />
  );
}
