import * as React from "react";
import FormControl from "@mui/material/FormControl";
import OutlinedInput from "@mui/material/OutlinedInput";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import styled from "@emotion/styled";
import { InputAdornment, Select } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import IconButton from "@mui/material/IconButton";

const StyledSelect = styled(Select)(({ theme }) => ({
  "& .MuiOutlinedInput-notchedOutline": {
    border: "none",
  },
  [theme.breakpoints.down("md")]: {},
}));

const SearchForm = ({
  size = "medium",
  query,
  setQuery,
  onSubmit,
  category,
  setCategory,
}) => {
  const categories = [
    {
      value: "Allergy and immunology",
      label: "Allergy and immunology",
    },
    {
      value: "Anesthesiology",
      label: "Anesthesiology",
    },
    {
      value: "Dermatology",
      label: "Dermatology",
    },
    {
      value: "Diagnostic radiology",
      label: "Diagnostic radiology",
    },
    {
      value: "Emergency medicine",
      label: "Emergency medicine",
    },
    {
      value: "Family medicine",
      label: "Family medicine",
    },
    {
      value: "Internal medicine",
      label: "Internal medicine",
    },
    {
      value: "Medical genetics",
      label: "Medical genetics",
    },
  ];

  return (
    <Box
      component="form"
      noValidate
      autoComplete="off"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit();
      }}
    >
      <FormControl sx={{ width: "100%" }}>
        <OutlinedInput
          sx={{ backgroundColor: "#fff", paddingLeft: 0 }}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder=""
          size={size}
          startAdornment={
            <InputAdornment position="start">
              <StyledSelect
                size={size}
                label="Select"
                value={category}
                onChange={(event) => setCategory(event.target.value)}
              >
                {categories.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </StyledSelect>
            </InputAdornment>
          }
          endAdornment={
            <InputAdornment position="end">
              <IconButton size={size} aria-label="search" type="submit">
                <SearchIcon />
              </IconButton>
            </InputAdornment>
          }
        />
      </FormControl>
    </Box>
  );
};

export default SearchForm;
