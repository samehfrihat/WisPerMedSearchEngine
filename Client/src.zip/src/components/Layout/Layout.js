import * as React from "react";
import Link from "@mui/material/Link";
import { useHistory } from "react-router";
import Box from "@mui/material/Box";
import ProfileButton from "../ProfileButton";
import useAuth from "../../hooks/useAuth";
import SearchForm from "../SearchForm";
import Stack from "@mui/material/Stack";
import Logo from "../Logo"
import useSearchForm from "../../hooks/useSearchForm";
const Layout = ({ children, search = true, logo = true }) => {
  const { isAuthorized } = useAuth();
  const history = useHistory();

  // access check
  if (!isAuthorized) {
    history.push({ pathname: "/login" });
  }

  const searchForm = useSearchForm()
  
  return (
    <>
      <Box
        sx={{ display: "flex", justifyContent: "space-between", padding: 1 }}
        component="header"
      >
        <Stack direction="row" alignItems="center" spacing={2}>
          {logo && (
               <Logo width="80px" height="80px" />
          )}

          {search && <SearchForm size="small" {...searchForm} />}
        </Stack>

        <ProfileButton />
      </Box>
  
      <main>{children}</main>


    </>
  );
};

export default Layout;
