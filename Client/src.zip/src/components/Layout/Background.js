import * as React from "react";
import Box from "@mui/material/Box";
import { Stack } from "@mui/material";



const Background = ({ children}) => {
return(
    <>
    <Box>
    {/* <Stack alignItems="center" direction="column" sx={{maxWidth:"10em" ,height:"25em" ,backgroundColor:"#B3D2F7" }}>
    </Stack> */}
    {/* {children} */}
    </Box>
    </>
);

  



};

export default Background;