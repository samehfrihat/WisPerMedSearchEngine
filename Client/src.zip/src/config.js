const url =
  process.env.REACT_APP_API_URL || "http://ariadne.is.inf.uni-due.de:7770";

export { url };
